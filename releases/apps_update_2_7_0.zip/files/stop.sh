#!/bin/bash
PANEL_PID_FILE="/root/umbrel_mobile/panel.pid"
TTYD_PID_FILE="/root/umbrel_mobile/ttyd.pid"

if [ -f "$PANEL_PID_FILE" ]; then
    PID=$(cat "$PANEL_PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then kill "$PID"; echo "Painel (PID $PID) finalizado."; fi
    rm -f "$PANEL_PID_FILE"
fi
if [ -f "$TTYD_PID_FILE" ]; then
    PID=$(cat "$TTYD_PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then kill "$PID"; echo "Terminal web (PID $PID) finalizado."; fi
    rm -f "$TTYD_PID_FILE"
fi
for PF in "/root/umbrel_mobile/desktop_novnc.pid" "/root/umbrel_mobile/desktop_vnc.pid" "/root/umbrel_mobile/desktop_wm.pid" "/root/umbrel_mobile/desktop_xvfb.pid" "/root/umbrel_mobile/pihole_ftl.pid"; do
    if [ -f "$PF" ]; then
        PID=$(cat "$PF")
        kill "$PID" 2>/dev/null
        rm -f "$PF"
    fi
done
