#!/bin/bash
# post_install.sh — roda automaticamente quando o "apps update" é aplicado.
# Prepara repositórios apt e instala os pacotes de sistema que os novos
# apps (Firefox, Jellyfin, Desktop remoto) precisam. Cada etapa é tolerante
# a falha (||true) pra uma etapa ruim não travar as outras.

echo "== apps update: post_install.sh =="

# 1) Impede que pacotes tentem "ligar" o próprio serviço durante o apt
#    install — dentro do proot isso trava o postinst e derruba o apt-get.
cat << 'POLEOF' > /usr/sbin/policy-rc.d
#!/bin/sh
exit 101
POLEOF
chmod +x /usr/sbin/policy-rc.d
echo "-- policy-rc.d instalado"

export DEBIAN_FRONTEND=noninteractive
apt-get update -y || true
apt-get install -y gnupg ca-certificates curl || true

# 2) Repositório oficial da Mozilla — Firefox de verdade, não o
#    redirecionador pro Snap que vem no repositório padrão do Ubuntu.
install -d -m 0755 /etc/apt/keyrings
if wget -q https://packages.mozilla.org/apt/repo-signing-key.gpg -O /etc/apt/keyrings/packages.mozilla.org.asc; then
    echo "deb [signed-by=/etc/apt/keyrings/packages.mozilla.org.asc] https://packages.mozilla.org/apt mozilla main" > /etc/apt/sources.list.d/mozilla.list
    cat << 'PINEOF' > /etc/apt/preferences.d/mozilla
Package: *
Pin: origin packages.mozilla.org
Pin-Priority: 1000
PINEOF
    echo "-- repositório da Mozilla configurado"
else
    echo "-- AVISO: não deu pra baixar a chave da Mozilla"
fi

# 3) Repositório oficial do Jellyfin (funciona em ARM64)
if curl -fsSL https://repo.jellyfin.org/ubuntu/jellyfin_team.gpg.key | gpg --dearmor -o /etc/apt/keyrings/jellyfin.gpg; then
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/jellyfin.gpg] https://repo.jellyfin.org/$(awk -F'=' '/^ID=/{print $NF}' /etc/os-release) $(awk -F'=' '/^VERSION_CODENAME=/{print $NF}' /etc/os-release) main" > /etc/apt/sources.list.d/jellyfin.list
    echo "-- repositório do Jellyfin configurado"
else
    echo "-- AVISO: não deu pra baixar a chave do Jellyfin"
fi

apt-get update -y || true

# 4) Pacotes do Desktop remoto (tela virtual + VNC + cliente web)
apt-get install -y xvfb fluxbox x11vnc novnc websockify || \
    echo "-- AVISO: falha ao instalar pacotes do Desktop remoto — tente 'apt-get install -y xvfb fluxbox x11vnc novnc websockify' manualmente pelo Terminal"

echo "== post_install.sh concluído =="
