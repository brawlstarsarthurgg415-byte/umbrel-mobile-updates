#!/usr/bin/env python3
"""
Umbrel OS Mobile v2 - Backend Flask
Painel de controle para Termux/proot-distro Ubuntu ARM64
"""
import os
import json
import subprocess
import signal
import time
import re
import zipfile
import shutil
import threading
import glob
import requests
from datetime import datetime
from functools import wraps

from flask import Flask, jsonify, request, render_template, redirect, url_for, session

try:
    import psutil
except ImportError:
    psutil = None

from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")
MC_DIR = os.path.join(DATA_DIR, "minecraft")
CATALOG_FILE = os.path.join(BASE_DIR, "apps_catalog.json")
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
INSTALLED_APPS_FILE = os.path.join(DATA_DIR, "installed_apps.json")
MC_PID_FILE = os.path.join(MC_DIR, "server.pid")
MC_LOG_FILE = os.path.join(MC_DIR, "paper.log")
PLAYIT_PID_FILE = os.path.join(BASE_DIR, "playit.pid")
PLAYIT_LOG_FILE = os.path.join(LOG_DIR, "playit.log")
PAPERMC_VERSION = "1.21.1"
TTYD_PORT = 7681

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(MC_DIR, exist_ok=True)

UPDATES_DIR = os.path.join(DATA_DIR, "updates")
UPDATES_STAGING_DIR = os.path.join(UPDATES_DIR, "staging")
UPDATES_BACKUP_DIR = os.path.join(UPDATES_DIR, "backups")
VERSION_FILE = os.path.join(BASE_DIR, "version.json")
os.makedirs(UPDATES_STAGING_DIR, exist_ok=True)
os.makedirs(UPDATES_BACKUP_DIR, exist_ok=True)


def load_config():
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


CONFIG = load_config()

app = Flask(__name__)
app.secret_key = CONFIG["secret_key"]
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["PERMANENT_SESSION_LIFETIME"] = 60 * 60 * 24 * 14  # 14 dias
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50 MB por pacote de atualização


@app.after_request
def no_cache(response):
    # Evita que o navegador guarde uma versão antiga do painel em cache
    # (causa comum de "sumiu um botão" depois de uma atualização ou reinício)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

# ---------------------------------------------------------------------------
# UTILITÁRIOS
# ---------------------------------------------------------------------------

def run_cmd(cmd, timeout=120, cwd=None):
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=cwd, capture_output=True,
            text=True, timeout=timeout
        )
        return {
            "success": result.returncode == 0,
            "returncode": result.returncode,
            "stdout": result.stdout[-8000:],
            "stderr": result.stderr[-4000:],
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "returncode": -1, "stdout": "", "stderr": "Comando excedeu o tempo limite."}
    except Exception as e:
        return {"success": False, "returncode": -1, "stdout": "", "stderr": str(e)}


def load_catalog():
    try:
        with open(CATALOG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def load_installed_apps():
    if not os.path.exists(INSTALLED_APPS_FILE):
        return []
    try:
        with open(INSTALLED_APPS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_installed_apps(apps):
    with open(INSTALLED_APPS_FILE, "w", encoding="utf-8") as f:
        json.dump(apps, f, indent=2, ensure_ascii=False)


def safe_name(name):
    return re.sub(r"[^a-zA-Z0-9._+-]", "", name)[:80]


def load_version():
    if not os.path.exists(VERSION_FILE):
        return {"version": "desconhecida", "history": []}
    try:
        with open(VERSION_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"version": "desconhecida", "history": []}


def save_version(data):
    with open(VERSION_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def safe_extract_zip(zip_path, dest_dir):
    """Extrai um zip protegendo contra path traversal (zip slip)."""
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.namelist():
            normalized = os.path.normpath(member)
            if normalized.startswith("..") or os.path.isabs(normalized):
                raise ValueError(f"Entrada suspeita no pacote: {member}")
        zf.extractall(dest_dir)


def parse_version(v):
    parts = []
    for p in str(v).split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) if parts else (0,)


def is_newer(remote_v, local_v):
    return parse_version(remote_v) > parse_version(local_v)


def stage_update_zip(zip_path):
    """Extrai um .zip de atualização já baixado/enviado para uma pasta de staging
    e devolve (staging_id, manifest, file_list, has_post_install) ou levanta ValueError."""
    staging_id = str(int(time.time()))
    staging_path = os.path.join(UPDATES_STAGING_DIR, staging_id)
    os.makedirs(staging_path, exist_ok=True)

    try:
        safe_extract_zip(zip_path, staging_path)
    except Exception as e:
        shutil.rmtree(staging_path, ignore_errors=True)
        raise ValueError(f"Pacote inválido: {e}")

    manifest_path = os.path.join(staging_path, "manifest.json")
    if not os.path.exists(manifest_path):
        shutil.rmtree(staging_path, ignore_errors=True)
        raise ValueError("manifest.json não encontrado no pacote.")

    with open(manifest_path, "r", encoding="utf-8") as mf:
        manifest = json.load(mf)

    files_dir = os.path.join(staging_path, "files")
    file_list = []
    if os.path.isdir(files_dir):
        for root, _, files in os.walk(files_dir):
            for fn in files:
                rel = os.path.relpath(os.path.join(root, fn), files_dir)
                file_list.append(rel)

    has_post_install = os.path.exists(os.path.join(staging_path, "post_install.sh"))
    return staging_id, manifest, file_list, has_post_install


def greeting():
    hour = datetime.now().hour
    if hour < 12:
        return "Bom dia"
    if hour < 18:
        return "Boa tarde"
    return "Boa noite"


# ---------------------------------------------------------------------------
# AUTENTICAÇÃO
# ---------------------------------------------------------------------------

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            if request.path.startswith("/api/"):
                return jsonify({"success": False, "error": "Sessão expirada. Faça login novamente."}), 401
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        cfg = load_config()
        user = request.form.get("username", "")
        pwd = request.form.get("password", "")
        if user == cfg.get("admin_user") and check_password_hash(cfg.get("password_hash", ""), pwd):
            session.clear()
            session["logged_in"] = True
            session["user"] = user
            session.permanent = True
            next_path = request.args.get("next") or url_for("index")
            return redirect(next_path)
        error = "Usuário ou senha incorretos."
    return render_template("login.html", error=error, greeting=greeting())


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/api/auth/change-password", methods=["POST"])
@login_required
def api_change_password():
    data = request.get_json(force=True, silent=True) or {}
    current = data.get("current_password", "")
    new_pw = data.get("new_password", "")
    cfg = load_config()
    if not check_password_hash(cfg.get("password_hash", ""), current):
        return jsonify({"success": False, "error": "Senha atual incorreta."}), 400
    if len(new_pw) < 4:
        return jsonify({"success": False, "error": "Nova senha deve ter ao menos 4 caracteres."}), 400
    cfg["password_hash"] = generate_password_hash(new_pw)
    save_config(cfg)
    ttyd_auth_path = os.path.join(BASE_DIR, ".ttyd_auth")
    try:
        with open(ttyd_auth_path, "w") as f:
            f.write(f"{cfg['admin_user']}:{new_pw}")
        os.chmod(ttyd_auth_path, 0o600)
    except Exception:
        pass
    return jsonify({"success": True, "note": "Reinicie o painel (stop.sh + start.sh) para aplicar a nova senha do terminal web."})


# ---------------------------------------------------------------------------
# ROTAS - PÁGINA PRINCIPAL
# ---------------------------------------------------------------------------

@app.route("/")
@login_required
def index():
    return render_template("index.html", user=session.get("user", "admin"), greeting=greeting(),
                            ttyd_port=TTYD_PORT)


# ---------------------------------------------------------------------------
# ROTAS - LOJA DE APLICATIVOS
# ---------------------------------------------------------------------------

@app.route("/api/apps/catalog")
@login_required
def api_apps_catalog():
    return jsonify({"success": True, "apps": load_catalog()})


@app.route("/api/apps/search")
@login_required
def api_apps_search():
    query = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip().lower()

    catalog = load_catalog()
    results = []

    for app_item in catalog:
        text = f"{app_item['name']} {app_item['desc']} {app_item['category']}".lower()
        if query and query.lower() not in text:
            continue
        if category and category != app_item["category"].lower():
            continue
        item = dict(app_item)
        item["source"] = "curated"
        results.append(item)

    if query and len(query) >= 2:
        safe_query = safe_name(query.replace(" ", "-"))
        cmd = f"apt-cache search {safe_query} 2>/dev/null | head -n 60"
        apt_result = run_cmd(cmd, timeout=20)
        if apt_result["success"] and apt_result["stdout"]:
            for line in apt_result["stdout"].splitlines():
                if " - " not in line:
                    continue
                pkg, _, desc = line.partition(" - ")
                pkg = pkg.strip()
                if any(r.get("pkg") == pkg for r in results):
                    continue
                results.append({
                    "id": pkg, "name": pkg, "category": "Repositório APT",
                    "desc": desc.strip(), "install_type": "apt", "pkg": pkg, "source": "apt"
                })

    return jsonify({"success": True, "count": len(results), "apps": results})


@app.route("/api/apps/install", methods=["POST"])
@login_required
def api_apps_install():
    data = request.get_json(force=True, silent=True) or {}
    install_type = data.get("install_type", "apt")
    pkg = safe_name(data.get("pkg", ""))
    app_id = safe_name(data.get("id", pkg))

    if not pkg and install_type not in ("script",):
        return jsonify({"success": False, "error": "Pacote não especificado."}), 400

    log_path = os.path.join(LOG_DIR, f"install_{app_id}.log")

    if install_type == "apt":
        cmd = f"apt-get install -y {pkg}"
    elif install_type == "pip":
        cmd = f"pip3 install --break-system-packages {pkg}"
    elif install_type == "script":
        script_name = safe_name(data.get("script", ""))
        return jsonify({
            "success": False,
            "error": f"'{script_name}' requer um instalador dedicado, não incluso neste painel base."
        }), 501
    elif install_type == "manual":
        return jsonify({"success": False, "error": data.get("note", "Este item requer ação manual.")}), 501
    else:
        return jsonify({"success": False, "error": "Tipo de instalação desconhecido."}), 400

    result = run_cmd(cmd, timeout=600)
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(f"CMD: {cmd}\n\nSTDOUT:\n{result['stdout']}\n\nSTDERR:\n{result['stderr']}\n")

    if result["success"]:
        installed = load_installed_apps()
        if not any(a["id"] == app_id for a in installed):
            catalog_entry = next((a for a in load_catalog() if a["id"] == app_id), None)
            installed.append({
                "id": app_id,
                "name": (catalog_entry or {}).get("name", app_id),
                "category": (catalog_entry or {}).get("category", "Repositório APT"),
                "install_type": install_type,
                "installed_at": datetime.now().isoformat()
            })
            save_installed_apps(installed)

    return jsonify({
        "success": result["success"],
        "log_tail": (result["stdout"][-1500:] + result["stderr"][-1500:]),
    })


@app.route("/api/apps/installed")
@login_required
def api_apps_installed():
    return jsonify({"success": True, "apps": load_installed_apps()})


@app.route("/api/apps/uninstall", methods=["POST"])
@login_required
def api_apps_uninstall():
    data = request.get_json(force=True, silent=True) or {}
    app_id = safe_name(data.get("id", ""))
    installed = load_installed_apps()
    entry = next((a for a in installed if a["id"] == app_id), None)
    if not entry:
        return jsonify({"success": False, "error": "App não está na lista de instalados."}), 400

    if entry.get("install_type") == "apt":
        pkg = safe_name(data.get("pkg", app_id))
        run_cmd(f"apt-get remove -y {pkg}", timeout=300)
    elif entry.get("install_type") == "pip":
        pkg = safe_name(data.get("pkg", app_id))
        run_cmd(f"pip3 uninstall -y {pkg}", timeout=120)

    installed = [a for a in installed if a["id"] != app_id]
    save_installed_apps(installed)
    return jsonify({"success": True})

# ---------------------------------------------------------------------------
# ROTAS - MINECRAFT (PAPERMC)
# ---------------------------------------------------------------------------

def find_mc_jar():
    """Procura o paper.jar; se não achar, usa qualquer .jar solto na raiz da pasta do Minecraft."""
    preferred = os.path.join(MC_DIR, "paper.jar")
    if os.path.exists(preferred):
        return preferred
    candidates = sorted(glob.glob(os.path.join(MC_DIR, "*.jar")))
    return candidates[0] if candidates else None


def get_mc_pid():
    if not os.path.exists(MC_PID_FILE):
        return None
    try:
        with open(MC_PID_FILE) as f:
            pid = int(f.read().strip())
        if psutil and psutil.pid_exists(pid):
            return pid
        if not psutil:
            os.kill(pid, 0)
            return pid
    except Exception:
        return None
    return None


@app.route("/api/mc/status")
@login_required
def api_mc_status():
    pid = get_mc_pid()
    jar_path = find_mc_jar()
    return jsonify({"success": True, "running": pid is not None, "pid": pid,
                     "jar_installed": jar_path is not None,
                     "jar_name": os.path.basename(jar_path) if jar_path else None,
                     "version": PAPERMC_VERSION})


@app.route("/api/mc/download", methods=["POST"])
@login_required
def api_mc_download():
    builds_url = f"https://api.papermc.io/v2/projects/paper/versions/{PAPERMC_VERSION}"
    result = run_cmd(f"curl -s {builds_url}", timeout=30)
    if not result["success"]:
        return jsonify({"success": False, "error": "Falha ao consultar API do PaperMC."}), 500
    try:
        builds = json.loads(result["stdout"])["builds"]
        latest_build = builds[-1]
    except Exception:
        return jsonify({"success": False, "error": "Não foi possível interpretar builds disponíveis."}), 500

    jar_name = f"paper-{PAPERMC_VERSION}-{latest_build}.jar"
    download_url = f"https://api.papermc.io/v2/projects/paper/versions/{PAPERMC_VERSION}/builds/{latest_build}/downloads/{jar_name}"
    dest = os.path.join(MC_DIR, "paper.jar")

    dl_result = run_cmd(f"curl -sL -o '{dest}' '{download_url}'", timeout=300)
    if not dl_result["success"] or not os.path.exists(dest):
        return jsonify({"success": False, "error": "Falha ao baixar o JAR do PaperMC."}), 500

    with open(os.path.join(MC_DIR, "eula.txt"), "w") as f:
        f.write(f"# Aceito automaticamente via painel em {datetime.now().isoformat()}\neula=true\n")

    return jsonify({"success": True, "build": latest_build, "jar": jar_name})


@app.route("/api/mc/start", methods=["POST"])
@login_required
def api_mc_start():
    if get_mc_pid():
        return jsonify({"success": False, "error": "Servidor já está rodando."}), 400
    jar_path = find_mc_jar()
    if not jar_path:
        return jsonify({"success": False, "error": "Nenhum arquivo .jar encontrado na pasta do Minecraft. Baixe o servidor ou coloque um .jar lá."}), 400

    data = request.get_json(force=True, silent=True) or {}
    ram_mb = int(data.get("ram_mb", 1024))
    ram_mb = max(512, min(ram_mb, 4096))

    java_flags = [
        f"-Xms{ram_mb}M", f"-Xmx{ram_mb}M", "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled",
        "-XX:MaxGCPauseMillis=200", "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC",
        "-XX:+AlwaysPreTouch", "-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40",
        "-XX:G1HeapRegionSize=8M", "-XX:G1ReservePercent=20", "-XX:G1HeapWastePercent=5",
        "-XX:G1MixedGCCountTarget=4", "-XX:InitiatingHeapOccupancyPercent=15",
        "-XX:G1MixedGCLiveThresholdPercent=90", "-XX:G1RSetUpdatingPauseTimePercent=5",
        "-XX:SurvivorRatio=32", "-XX:+PerfDisableSharedMem", "-XX:MaxTenuringThreshold=1"
    ]
    proc = subprocess.Popen(
        f"java {' '.join(java_flags)} -jar {jar_path} nogui",
        shell=True, cwd=MC_DIR,
        stdout=open(MC_LOG_FILE, "a"), stderr=subprocess.STDOUT,
        preexec_fn=os.setsid
    )
    with open(MC_PID_FILE, "w") as f:
        f.write(str(proc.pid))
    return jsonify({"success": True, "pid": proc.pid, "ram_mb": ram_mb})


@app.route("/api/mc/stop", methods=["POST"])
@login_required
def api_mc_stop():
    pid = get_mc_pid()
    if not pid:
        return jsonify({"success": False, "error": "Servidor não está rodando."}), 400
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
        time.sleep(2)
        if psutil and psutil.pid_exists(pid):
            os.killpg(os.getpgid(pid), signal.SIGKILL)
    except ProcessLookupError:
        pass
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        if os.path.exists(MC_PID_FILE):
            os.remove(MC_PID_FILE)
    return jsonify({"success": True})


@app.route("/api/mc/restart", methods=["POST"])
@login_required
def api_mc_restart():
    api_mc_stop()
    time.sleep(1)
    return api_mc_start()


@app.route("/api/mc/logs")
@login_required
def api_mc_logs():
    lines = int(request.args.get("lines", 200))
    if not os.path.exists(MC_LOG_FILE):
        return jsonify({"success": True, "log": ""})
    result = run_cmd(f"tail -n {lines} '{MC_LOG_FILE}'", timeout=10)
    return jsonify({"success": True, "log": result["stdout"]})


# ---------------------------------------------------------------------------
# ROTAS - PLAYIT.GG (acesso externo ao servidor Minecraft)
# ---------------------------------------------------------------------------

def get_playit_pid():
    if not os.path.exists(PLAYIT_PID_FILE):
        return None
    try:
        with open(PLAYIT_PID_FILE) as f:
            pid = int(f.read().strip())
        if psutil and psutil.pid_exists(pid):
            return pid
        if not psutil:
            os.kill(pid, 0)
            return pid
    except Exception:
        return None
    return None


@app.route("/api/playit/status")
@login_required
def api_playit_status():
    installed = run_cmd("command -v playit", timeout=10)["success"]
    pid = get_playit_pid()
    return jsonify({"success": True, "installed": installed, "running": pid is not None, "pid": pid})


@app.route("/api/playit/install", methods=["POST"])
@login_required
def api_playit_install():
    cmd = (
        "curl -SsL https://playit-cloud.github.io/ppa/key.gpg | gpg --dearmor -o /etc/apt/trusted.gpg.d/playit.gpg "
        "&& echo 'deb [signed-by=/etc/apt/trusted.gpg.d/playit.gpg] https://playit-cloud.github.io/ppa/data ./' "
        "> /etc/apt/sources.list.d/playit-cloud.list "
        "&& apt-get update -y && apt-get install -y playit"
    )
    result = run_cmd(cmd, timeout=180)
    return jsonify({"success": result["success"], "log": (result["stdout"] + result["stderr"])[-2000:]})


@app.route("/api/playit/start", methods=["POST"])
@login_required
def api_playit_start():
    if get_playit_pid():
        return jsonify({"success": False, "error": "Túnel já está rodando."}), 400
    if not run_cmd("command -v playit", timeout=10)["success"]:
        return jsonify({"success": False, "error": "Playit não instalado. Instale primeiro."}), 400

    proc = subprocess.Popen(
        "playit", shell=True, cwd=BASE_DIR,
        stdout=open(PLAYIT_LOG_FILE, "a"), stderr=subprocess.STDOUT,
        preexec_fn=os.setsid
    )
    with open(PLAYIT_PID_FILE, "w") as f:
        f.write(str(proc.pid))
    return jsonify({"success": True, "pid": proc.pid})


@app.route("/api/playit/stop", methods=["POST"])
@login_required
def api_playit_stop():
    pid = get_playit_pid()
    if not pid:
        return jsonify({"success": False, "error": "Túnel não está rodando."}), 400
    try:
        os.killpg(os.getpgid(pid), signal.SIGTERM)
    except ProcessLookupError:
        pass
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        if os.path.exists(PLAYIT_PID_FILE):
            os.remove(PLAYIT_PID_FILE)
    return jsonify({"success": True})


@app.route("/api/playit/logs")
@login_required
def api_playit_logs():
    if not os.path.exists(PLAYIT_LOG_FILE):
        return jsonify({"success": True, "log": ""})
    result = run_cmd(f"tail -n 80 '{PLAYIT_LOG_FILE}'", timeout=10)
    return jsonify({"success": True, "log": result["stdout"]})


# ---------------------------------------------------------------------------
# ROTAS - MONITOR DE SISTEMA
# ---------------------------------------------------------------------------

def strip_ansi(text):
    return re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", text)


@app.route("/api/system/fastfetch")
@login_required
def api_system_fastfetch():
    # SHELL setado e chamada via 'bash -lc' evitam o fastfetch detectar "Shell: app.py"
    # (ele olha o processo pai, que sem isso é o próprio Python do painel)
    cmd = "SHELL=/bin/bash bash -lc \"fastfetch --logo none --pipe -s Title:OS:Kernel:Uptime:Packages:Shell:Terminal:CPU:Memory:Disk:Locale 2>/dev/null || fastfetch --logo none --pipe 2>/dev/null\""
    result = run_cmd(cmd, timeout=15)
    if result["success"] and result["stdout"]:
        return jsonify({"success": True, "output": strip_ansi(result["stdout"])})
    return jsonify({"success": False, "output": "fastfetch indisponível neste ambiente."})


@app.route("/api/system/stats")
@login_required
def api_system_stats():
    stats = {"success": True}
    if psutil:
        stats["cpu_percent"] = psutil.cpu_percent(interval=0.3)
        mem = psutil.virtual_memory()
        stats["ram_total_mb"] = round(mem.total / 1024 / 1024, 1)
        stats["ram_used_mb"] = round(mem.used / 1024 / 1024, 1)
        stats["ram_percent"] = mem.percent
        disk = psutil.disk_usage(BASE_DIR)
        stats["disk_total_gb"] = round(disk.total / 1024 / 1024 / 1024, 1)
        stats["disk_used_gb"] = round(disk.used / 1024 / 1024 / 1024, 1)
        stats["disk_percent"] = disk.percent
        # Tempo de vida do PAINEL (não do aparelho — dentro do proot o boot_time do
        # dispositivo pode vir incorreto/enorme, então usamos o processo do painel)
        try:
            stats["boot_time"] = psutil.Process(os.getpid()).create_time()
        except Exception:
            stats["boot_time"] = time.time()
    else:
        stats["error"] = "psutil não disponível"
    return jsonify(stats)


# ---------------------------------------------------------------------------
# ROTAS - TERMINAL WEB (ttyd)
# ---------------------------------------------------------------------------

@app.route("/api/terminal/status")
@login_required
def api_terminal_status():
    result = run_cmd(f"pgrep -f 'ttyd -p {TTYD_PORT}'", timeout=10)
    running = bool(result["stdout"].strip())
    return jsonify({"success": True, "running": running, "port": TTYD_PORT})


# ---------------------------------------------------------------------------
# ROTAS - REDE / ACESSO REMOTO
# ---------------------------------------------------------------------------

@app.route("/api/system/network")
@login_required
def api_system_network():
    result = run_cmd("hostname -I 2>/dev/null", timeout=10)
    ips = result["stdout"].split() if result["success"] else []
    tailscale_ips = [ip for ip in ips if ip.startswith("100.")]
    return jsonify({
        "success": True,
        "ips": ips,
        "tailscale_detected": len(tailscale_ips) > 0,
        "tailscale_ips": tailscale_ips,
        "panel_port": 9000,
        "ttyd_port": TTYD_PORT
    })


# ---------------------------------------------------------------------------
# ROTAS - GITHUB / DOWNLOAD DE ARQUIVOS
# ---------------------------------------------------------------------------

@app.route("/api/github/clone", methods=["POST"])
@login_required
def api_github_clone():
    data = request.get_json(force=True, silent=True) or {}
    repo_url = data.get("url", "").strip()
    if not repo_url.startswith("https://github.com/"):
        return jsonify({"success": False, "error": "Forneça uma URL válida do GitHub (https://github.com/...)."}), 400
    repo_name = safe_name(repo_url.rstrip("/").split("/")[-1].replace(".git", ""))
    dest = os.path.join(DATA_DIR, "downloads", repo_name)
    if os.path.exists(dest):
        return jsonify({"success": False, "error": f"Diretório '{repo_name}' já existe."}), 400
    result = run_cmd(f"git clone --depth 1 '{repo_url}' '{dest}'", timeout=180)
    return jsonify({"success": result["success"], "path": dest, "log": result["stdout"] + result["stderr"]})


@app.route("/api/download/url", methods=["POST"])
@login_required
def api_download_url():
    data = request.get_json(force=True, silent=True) or {}
    url = data.get("url", "").strip()
    if not url.startswith(("http://", "https://")):
        return jsonify({"success": False, "error": "URL inválida."}), 400
    filename = safe_name(os.path.basename(url).split("?")[0]) or f"download_{int(time.time())}"
    dest = os.path.join(DATA_DIR, "downloads", filename)
    result = run_cmd(f"curl -sL -o '{dest}' '{url}'", timeout=300)
    if result["success"] and os.path.exists(dest):
        return jsonify({"success": True, "path": dest, "size_bytes": os.path.getsize(dest)})
    return jsonify({"success": False, "error": "Falha no download."}), 500


# ---------------------------------------------------------------------------
# ROTAS - SISTEMA DE ATUALIZAÇÕES
# ---------------------------------------------------------------------------

@app.route("/api/update/status")
@login_required
def api_update_status():
    return jsonify({"success": True, "current": load_version()})


@app.route("/api/update/upload", methods=["POST"])
@login_required
def api_update_upload():
    if "update_file" not in request.files:
        return jsonify({"success": False, "error": "Nenhum arquivo enviado."}), 400
    f = request.files["update_file"]
    if not f.filename.endswith(".zip"):
        return jsonify({"success": False, "error": "O pacote de atualização precisa ser um .zip."}), 400

    tmp_zip = os.path.join(UPDATES_STAGING_DIR, f"upload_{int(time.time())}.zip")
    f.save(tmp_zip)

    try:
        staging_id, manifest, file_list, has_post_install = stage_update_zip(tmp_zip)
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    finally:
        if os.path.exists(tmp_zip):
            os.remove(tmp_zip)

    return jsonify({
        "success": True, "staging_id": staging_id, "manifest": manifest,
        "files": file_list, "has_post_install": has_post_install
    })


@app.route("/api/update/settings", methods=["GET", "POST"])
@login_required
def api_update_settings():
    cfg = load_config()
    if request.method == "POST":
        data = request.get_json(force=True, silent=True) or {}
        url = data.get("update_manifest_url", "").strip()
        cfg["update_manifest_url"] = url
        save_config(cfg)
        return jsonify({"success": True, "update_manifest_url": url})
    return jsonify({"success": True, "update_manifest_url": cfg.get("update_manifest_url", "")})


@app.route("/api/update/remote-check")
@login_required
def api_update_remote_check():
    cfg = load_config()
    manifest_url = cfg.get("update_manifest_url", "").strip()
    if not manifest_url:
        return jsonify({"success": True, "configured": False})

    try:
        resp = requests.get(manifest_url, timeout=10)
        resp.raise_for_status()
        remote = resp.json()
    except Exception as e:
        return jsonify({"success": False, "configured": True, "error": f"Falha ao verificar: {e}"}), 502

    current = load_version().get("version", "0")
    remote_version = remote.get("version", "0")
    return jsonify({
        "success": True, "configured": True,
        "update_available": is_newer(remote_version, current),
        "current_version": current,
        "remote": remote
    })


@app.route("/api/update/remote-stage", methods=["POST"])
@login_required
def api_update_remote_stage():
    cfg = load_config()
    manifest_url = cfg.get("update_manifest_url", "").strip()
    if not manifest_url:
        return jsonify({"success": False, "error": "Nenhum endereço de atualização configurado."}), 400

    try:
        resp = requests.get(manifest_url, timeout=10)
        resp.raise_for_status()
        remote = resp.json()
    except Exception as e:
        return jsonify({"success": False, "error": f"Falha ao consultar manifest remoto: {e}"}), 502

    download_url = remote.get("download_url", "")
    if not download_url:
        return jsonify({"success": False, "error": "Manifest remoto não tem 'download_url'."}), 400

    tmp_zip = os.path.join(UPDATES_STAGING_DIR, f"remote_{int(time.time())}.zip")
    try:
        with requests.get(download_url, timeout=60, stream=True) as r:
            r.raise_for_status()
            with open(tmp_zip, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
    except Exception as e:
        return jsonify({"success": False, "error": f"Falha ao baixar pacote: {e}"}), 502

    try:
        staging_id, manifest, file_list, has_post_install = stage_update_zip(tmp_zip)
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    finally:
        if os.path.exists(tmp_zip):
            os.remove(tmp_zip)

    return jsonify({
        "success": True, "staging_id": staging_id, "manifest": manifest,
        "files": file_list, "has_post_install": has_post_install
    })


@app.route("/api/update/apply", methods=["POST"])
@login_required
def api_update_apply():
    data = request.get_json(force=True, silent=True) or {}
    staging_id = safe_name(data.get("staging_id", ""))
    staging_path = os.path.join(UPDATES_STAGING_DIR, staging_id)
    manifest_path = os.path.join(staging_path, "manifest.json")
    files_dir = os.path.join(staging_path, "files")

    if not os.path.exists(manifest_path):
        return jsonify({"success": False, "error": "Pacote não encontrado ou expirado. Envie novamente."}), 400

    with open(manifest_path, "r", encoding="utf-8") as mf:
        manifest = json.load(mf)

    backup_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(UPDATES_BACKUP_DIR, backup_id)
    os.makedirs(backup_path, exist_ok=True)

    file_list = []
    if os.path.isdir(files_dir):
        for root, _, files in os.walk(files_dir):
            for fn in files:
                rel = os.path.relpath(os.path.join(root, fn), files_dir)
                file_list.append(rel)
                current_file = os.path.join(BASE_DIR, rel)
                if os.path.exists(current_file):
                    backup_target = os.path.join(backup_path, rel)
                    os.makedirs(os.path.dirname(backup_target), exist_ok=True)
                    shutil.copy2(current_file, backup_target)

    for rel in file_list:
        src = os.path.join(files_dir, rel)
        dst = os.path.join(BASE_DIR, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)

    post_install_log = ""
    post_install_path = os.path.join(staging_path, "post_install.sh")
    if os.path.exists(post_install_path):
        os.chmod(post_install_path, 0o755)
        result = run_cmd(f"bash '{post_install_path}'", timeout=300, cwd=BASE_DIR)
        post_install_log = result["stdout"] + result["stderr"]

    version_data = load_version()
    version_data["version"] = manifest.get("version", "desconhecida")
    version_data.setdefault("history", []).insert(0, {
        "version": manifest.get("version", "desconhecida"),
        "description": manifest.get("description", ""),
        "applied_at": datetime.now().isoformat(),
        "backup_id": backup_id,
        "files_changed": len(file_list)
    })
    version_data["history"] = version_data["history"][:20]
    save_version(version_data)

    shutil.rmtree(staging_path, ignore_errors=True)

    def delayed_restart():
        time.sleep(2)
        run_cmd(f"bash '{os.path.join(BASE_DIR, 'stop.sh')}' && bash '{os.path.join(BASE_DIR, 'start.sh')}'", timeout=60)

    threading.Thread(target=delayed_restart, daemon=True).start()

    return jsonify({
        "success": True,
        "version": manifest.get("version"),
        "files_changed": len(file_list),
        "backup_id": backup_id,
        "post_install_log": post_install_log[-2000:],
        "restarting": True
    })


@app.route("/api/update/rollback", methods=["POST"])
@login_required
def api_update_rollback():
    version_data = load_version()
    history = version_data.get("history", [])
    if not history:
        return jsonify({"success": False, "error": "Nenhuma atualização para reverter."}), 400

    last = history[0]
    backup_id = last.get("backup_id")
    backup_path = os.path.join(UPDATES_BACKUP_DIR, backup_id) if backup_id else None
    if not backup_path or not os.path.isdir(backup_path):
        return jsonify({"success": False, "error": "Backup dessa atualização não foi encontrado."}), 400

    restored = 0
    for root, _, files in os.walk(backup_path):
        for fn in files:
            src = os.path.join(root, fn)
            rel = os.path.relpath(src, backup_path)
            dst = os.path.join(BASE_DIR, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            restored += 1

    history.pop(0)
    version_data["history"] = history
    version_data["version"] = history[0]["version"] if history else "revertido"
    save_version(version_data)

    def delayed_restart():
        time.sleep(2)
        run_cmd(f"bash '{os.path.join(BASE_DIR, 'stop.sh')}' && bash '{os.path.join(BASE_DIR, 'start.sh')}'", timeout=60)

    threading.Thread(target=delayed_restart, daemon=True).start()

    return jsonify({"success": True, "restored_files": restored, "restarting": True})


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    port = int(os.environ.get("UMBREL_PANEL_PORT", 9000))
    print(f"Umbrel OS Mobile rodando em http://0.0.0.0:{port}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)