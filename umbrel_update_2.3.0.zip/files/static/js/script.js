// Umbrel OS Mobile v2 - Front-end logic

function showToast(message, type = "info") {
  const el = document.createElement("div");
  el.className = `toast-item ${type}`;
  el.textContent = message;
  document.getElementById("toastContainer").appendChild(el);
  setTimeout(() => el.remove(), 5000);
}

async function apiFetch(url, options = {}) {
  const res = await fetch(url, options);
  if (res.status === 401) {
    window.location.href = "/login";
    throw new Error("Sessão expirada");
  }
  return res;
}

const ICONS = {
  "Servidor Web": "fa-server", "Banco de Dados": "fa-database",
  "Armazenamento & Nuvem": "fa-cloud", "Downloads": "fa-download",
  "Desenvolvimento": "fa-code", "Ferramentas CLI": "fa-terminal",
  "Monitoramento": "fa-chart-line", "Multimídia": "fa-photo-film",
  "Rede & Acesso Remoto": "fa-network-wired", "Jogos": "fa-gamepad",
  "Casa & Automação": "fa-house-signal", "Segurança": "fa-shield-halved",
  "Repositório APT": "fa-box"
};
function iconFor(cat) { return ICONS[cat] || "fa-cube"; }

// ---- Navegação entre abas ----
document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".tab-pane").forEach(p => p.classList.add("d-none"));
    document.getElementById(`tab-${btn.dataset.tab}`).classList.remove("d-none");
    if (btn.dataset.tab === "minecraft") { refreshMcStatus(); refreshMcLogs(); refreshPlayitStatus(); refreshPlayitLogs(); }
    if (btn.dataset.tab === "monitor") { refreshSystemStats(); refreshFastfetch(); }
    if (btn.dataset.tab === "terminal") { refreshTerminalStatus(); }
    if (btn.dataset.tab === "remote") { refreshNetworkInfo(); }
    if (btn.dataset.tab === "updates") { refreshUpdateStatus(); }
  });
});

// ---- APP STORE ----
const appGrid = document.getElementById("appGrid");
const appSearch = document.getElementById("appSearch");
const appResultsInfo = document.getElementById("appResultsInfo");
let searchTimeout = null;

function renderApps(apps) {
  appGrid.innerHTML = "";
  if (!apps.length) {
    appGrid.innerHTML = `<div class="muted" style="grid-column:1/-1;text-align:center;padding:20px 0;">Nenhum aplicativo encontrado.</div>`;
    return;
  }
  apps.forEach(app => {
    const tile = document.createElement("div");
    tile.className = "app-tile";
    tile.innerHTML = `
      <div class="icon"><i class="fa-solid ${iconFor(app.category)}"></i></div>
      <div class="name">${app.name}</div>
      <div class="cat">${app.category}</div>
      <button class="install-btn"><i class="fa-solid fa-download"></i></button>`;
    tile.querySelector(".install-btn").addEventListener("click", (e) => installApp(app, e.currentTarget));
    appGrid.appendChild(tile);
  });
}

async function loadCatalog() {
  const res = await apiFetch("/api/apps/catalog");
  const data = await res.json();
  renderApps(data.apps || []);
  appResultsInfo.textContent = `${data.apps.length} apps curados — digite para buscar em todo o repositório Ubuntu.`;
}

async function searchApps(query) {
  const res = await apiFetch(`/api/apps/search?q=${encodeURIComponent(query)}`);
  const data = await res.json();
  renderApps(data.apps || []);
  appResultsInfo.textContent = `${data.count} resultado(s) para "${query}"`;
}

appSearch.addEventListener("input", () => {
  clearTimeout(searchTimeout);
  const q = appSearch.value.trim();
  searchTimeout = setTimeout(() => { q.length === 0 ? loadCatalog() : searchApps(q); }, 400);
});

async function installApp(app, btnEl) {
  btnEl.disabled = true;
  btnEl.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i>`;
  try {
    const res = await apiFetch("/api/apps/install", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: app.id, pkg: app.pkg, install_type: app.install_type, script: app.script, note: app.note })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`${app.name} instalado.`, "success");
      btnEl.innerHTML = `<i class="fa-solid fa-check"></i>`;
      loadInstalledApps();
    } else {
      showToast(`${app.name}: ${data.error || "falha"}`, "error");
      btnEl.disabled = false;
      btnEl.innerHTML = `<i class="fa-solid fa-download"></i>`;
    }
  } catch (err) {
    showToast(`Erro de rede ao instalar ${app.name}.`, "error");
    btnEl.disabled = false;
    btnEl.innerHTML = `<i class="fa-solid fa-download"></i>`;
  }
}

// ---- MINECRAFT ----
async function refreshMcStatus() {
  const res = await apiFetch("/api/mc/status");
  const data = await res.json();
  const badge = document.getElementById("mcStatusBadge");
  const pidLabel = document.getElementById("mcPidLabel");
  if (data.running) {
    badge.textContent = "Rodando"; badge.className = "badge badge-success";
    pidLabel.textContent = `PID ${data.pid}`;
  } else {
    badge.textContent = data.jar_installed ? "Parado" : "Servidor não baixado";
    badge.className = data.jar_installed ? "badge badge-secondary" : "badge badge-warning";
    pidLabel.textContent = "";
  }
}

async function refreshMcLogs() {
  const res = await apiFetch("/api/mc/logs?lines=200");
  const data = await res.json();
  const out = document.getElementById("mcLogOutput");
  out.textContent = data.log || "Sem logs ainda.";
  out.scrollTop = out.scrollHeight;
}

document.getElementById("btnMcDownload").addEventListener("click", async (e) => {
  e.currentTarget.disabled = true;
  showToast("Baixando PaperMC 1.21.1...", "info");
  const res = await apiFetch("/api/mc/download", { method: "POST" });
  const data = await res.json();
  e.currentTarget.disabled = false;
  if (data.success) showToast(`PaperMC build ${data.build} baixado.`, "success");
  else showToast(`Erro: ${data.error}`, "error");
  refreshMcStatus();
});
document.getElementById("btnMcStart").addEventListener("click", async () => {
  const ram = parseInt(document.getElementById("mcRam").value || "1024", 10);
  const res = await apiFetch("/api/mc/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ram_mb: ram }) });
  const data = await res.json();
  showToast(data.success ? `Servidor iniciado (PID ${data.pid}).` : `Erro: ${data.error}`, data.success ? "success" : "error");
  refreshMcStatus();
});
document.getElementById("btnMcStop").addEventListener("click", async () => {
  const res = await apiFetch("/api/mc/stop", { method: "POST" });
  const data = await res.json();
  showToast(data.success ? "Servidor parado." : `Erro: ${data.error}`, data.success ? "success" : "error");
  refreshMcStatus();
});
document.getElementById("btnMcRestart").addEventListener("click", async () => {
  showToast("Reiniciando servidor...", "info");
  const res = await apiFetch("/api/mc/restart", { method: "POST" });
  const data = await res.json();
  showToast(data.success ? "Servidor reiniciado." : `Erro: ${data.error}`, data.success ? "success" : "error");
  refreshMcStatus();
});
document.getElementById("btnMcRefreshLogs").addEventListener("click", refreshMcLogs);

// ---- PLAYIT.GG ----
async function refreshPlayitStatus() {
  const res = await apiFetch("/api/playit/status");
  const data = await res.json();
  const badge = document.getElementById("playitStatusBadge");
  if (data.running) {
    badge.textContent = "Túnel ativo"; badge.className = "badge badge-success";
  } else if (data.installed) {
    badge.textContent = "Instalado, túnel parado"; badge.className = "badge badge-secondary";
  } else {
    badge.textContent = "Não instalado"; badge.className = "badge badge-warning";
  }
}
async function refreshPlayitLogs() {
  const res = await apiFetch("/api/playit/logs");
  const data = await res.json();
  const out = document.getElementById("playitLogOutput");
  out.textContent = data.log || "Sem logs ainda.";
  out.scrollTop = out.scrollHeight;
}
document.getElementById("btnPlayitInstall").addEventListener("click", async (e) => {
  e.currentTarget.disabled = true;
  showToast("Instalando playit.gg...", "info");
  const res = await apiFetch("/api/playit/install", { method: "POST" });
  const data = await res.json();
  e.currentTarget.disabled = false;
  showToast(data.success ? "Playit.gg instalado." : "Falha ao instalar playit.gg.", data.success ? "success" : "error");
  refreshPlayitStatus();
});
document.getElementById("btnPlayitStart").addEventListener("click", async () => {
  const res = await apiFetch("/api/playit/start", { method: "POST" });
  const data = await res.json();
  showToast(data.success ? "Túnel iniciado — confira o log pra ver o link de autorização." : `Erro: ${data.error}`, data.success ? "success" : "error");
  refreshPlayitStatus();
  setTimeout(refreshPlayitLogs, 1500);
});
document.getElementById("btnPlayitStop").addEventListener("click", async () => {
  const res = await apiFetch("/api/playit/stop", { method: "POST" });
  const data = await res.json();
  showToast(data.success ? "Túnel parado." : `Erro: ${data.error}`, data.success ? "success" : "error");
  refreshPlayitStatus();
});
document.getElementById("btnPlayitRefreshLogs").addEventListener("click", refreshPlayitLogs);

// ---- TERMINAL ----
async function refreshTerminalStatus() {
  const badge = document.getElementById("terminalStatusBadge");
  const btn = document.getElementById("btnOpenTerminal");
  const port = window.TTYD_PORT || 7681;
  btn.href = `${window.location.protocol}//${window.location.hostname}:${port}`;
  try {
    const res = await apiFetch("/api/terminal/status");
    const data = await res.json();
    if (data.running) {
      badge.textContent = "Disponível"; badge.className = "badge badge-success";
    } else {
      badge.textContent = "Indisponível — reinicie o painel (start.sh)"; badge.className = "badge badge-warning";
    }
  } catch (e) { /* já redirecionado se 401 */ }
}

// ---- REMOTO / REDE ----
async function refreshNetworkInfo() {
  const box = document.getElementById("networkInfo");
  const res = await apiFetch("/api/system/network");
  const data = await res.json();
  let html = `<strong>IPs deste dispositivo:</strong><br>${(data.ips || []).join(", ") || "nenhum encontrado"}`;
  if (data.tailscale_detected) {
    html += `<br><br><strong style="color:var(--accent)">✓ Tailscale detectado:</strong> ${data.tailscale_ips.join(", ")}`;
  } else {
    html += `<br><br><em>Tailscale ainda não detectado neste dispositivo.</em>`;
  }
  box.innerHTML = html;
}

// ---- ATUALIZAÇÕES ----
let stagedUpdateId = null;

async function refreshUpdateStatus() {
  const res = await apiFetch("/api/update/status");
  const data = await res.json();
  document.getElementById("currentVersionBadge").textContent = data.current.version || "--";
  renderUpdateHistory(data.current.history || []);
}

function renderUpdateHistory(history) {
  const box = document.getElementById("updateHistory");
  if (!history.length) {
    box.innerHTML = `<div class="muted">Nenhuma atualização registrada ainda.</div>`;
    return;
  }
  box.innerHTML = history.map(h => `
    <div class="update-hist-item">
      <strong>v${h.version}</strong> — ${h.description || "sem descrição"}
      <div class="muted small">${new Date(h.applied_at).toLocaleString("pt-BR")} · ${h.files_changed} arquivo(s)</div>
    </div>`).join("");
}

document.getElementById("btnUploadUpdate").addEventListener("click", async () => {
  const input = document.getElementById("updateFileInput");
  if (!input.files.length) { showToast("Selecione um arquivo .zip primeiro.", "error"); return; }
  const formData = new FormData();
  formData.append("update_file", input.files[0]);
  showToast("Enviando pacote...", "info");
  try {
    const res = await apiFetch("/api/update/upload", { method: "POST", body: formData });
    const data = await res.json();
    if (!data.success) { showToast(data.error, "error"); return; }
    stagedUpdateId = data.staging_id;
    const preview = document.getElementById("updatePreview");
    preview.classList.remove("d-none");
    preview.innerHTML = `
      <div class="update-hist-item">
        <strong>v${data.manifest.version || "?"}</strong> — ${data.manifest.description || ""}
        <div class="muted small">${data.files.length} arquivo(s) serão substituídos${data.has_post_install ? " · inclui script pós-instalação" : ""}</div>
      </div>
      <button class="btn btn-primary btn-sm" id="btnConfirmApply"><i class="fa-solid fa-check"></i> Aplicar esta atualização</button>`;
    document.getElementById("btnConfirmApply").addEventListener("click", applyStagedUpdate);
  } catch (e) {
    showToast("Erro ao enviar o pacote.", "error");
  }
});

async function applyStagedUpdate() {
  if (!stagedUpdateId) return;
  const progress = document.getElementById("updateProgress");
  progress.classList.remove("d-none");
  try {
    const res = await apiFetch("/api/update/apply", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ staging_id: stagedUpdateId })
    });
    const data = await res.json();
    if (data.success) {
      showToast(`Atualizado para v${data.version}. Painel reiniciando...`, "success");
      setTimeout(() => window.location.reload(), 6000);
    } else {
      showToast(data.error, "error");
      progress.classList.add("d-none");
    }
  } catch (e) {
    setTimeout(() => window.location.reload(), 6000);
  }
}

document.getElementById("btnRollback").addEventListener("click", async () => {
  if (!confirm("Reverter para a versão anterior? Isso restaura os arquivos do backup mais recente.")) return;
  const res = await apiFetch("/api/update/rollback", { method: "POST" });
  const data = await res.json();
  if (data.success) {
    showToast("Revertido. Painel reiniciando...", "success");
    setTimeout(() => window.location.reload(), 6000);
  } else {
    showToast(data.error, "error");
  }
});

// ---- MONITOR ----
async function refreshSystemStats() {
  const res = await apiFetch("/api/system/stats");
  const data = await res.json();
  if (data.success && data.cpu_percent !== undefined) {
    document.getElementById("statCpu").textContent = `${data.cpu_percent}%`;
    document.getElementById("statRam").textContent = `${data.ram_percent}%`;
    document.getElementById("statDisk").textContent = `${data.disk_percent}%`;
    if (data.boot_time) {
      const uptimeSec = Math.floor(Date.now() / 1000 - data.boot_time);
      const h = Math.floor(uptimeSec / 3600), m = Math.floor((uptimeSec % 3600) / 60);
      document.getElementById("statUptime").textContent = `${h}h ${m}m`;
    }
  }
}
async function refreshFastfetch() {
  const res = await apiFetch("/api/system/fastfetch");
  const data = await res.json();
  document.getElementById("fastfetchOutput").textContent = data.output || "Indisponível.";
}

// ---- APPS INSTALADOS (ícones na tela inicial, estilo Umbrel) ----
async function loadInstalledApps() {
  const box = document.getElementById("heroApps");
  try {
    const res = await apiFetch("/api/apps/installed");
    const data = await res.json();
    const apps = data.apps || [];
    if (!apps.length) {
      box.innerHTML = `<div class="hero-empty">Nenhum app instalado ainda — veja a aba Loja</div>`;
      return;
    }
    box.innerHTML = apps.map(app => `
      <div class="hero-app-icon" data-id="${app.id}" title="${app.name}">
        <div class="hero-app-circle"><i class="fa-solid ${iconFor(app.category)}"></i></div>
        <div class="hero-app-label">${app.name}</div>
      </div>`).join("");
    box.querySelectorAll(".hero-app-icon").forEach(el => {
      el.addEventListener("click", () => {
        const app = apps.find(a => a.id === el.dataset.id);
        showToast(`${app.name} — instalado via ${app.install_type}. Gerencie pelo Terminal se precisar.`, "info");
      });
    });
  } catch (e) { /* já redireciona em 401 */ }
}

// ---- CHECAGEM REMOTA DE ATUALIZAÇÃO ----
let remoteStagedId = null;
let remoteManifestCache = null;

async function loadRemoteUrlSetting() {
  const res = await apiFetch("/api/update/settings");
  const data = await res.json();
  document.getElementById("remoteUrlInput").value = data.update_manifest_url || "";
}

document.getElementById("btnSaveRemoteUrl").addEventListener("click", async () => {
  const url = document.getElementById("remoteUrlInput").value.trim();
  const res = await apiFetch("/api/update/settings", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ update_manifest_url: url })
  });
  const data = await res.json();
  showToast(data.success ? "Endereço salvo." : "Erro ao salvar.", data.success ? "success" : "error");
});

async function checkRemoteUpdate(showResultToast) {
  try {
    const res = await apiFetch("/api/update/remote-check");
    const data = await res.json();
    const info = document.getElementById("remoteCheckInfo");
    if (!data.configured) {
      if (info) info.textContent = "Nenhum endereço configurado ainda.";
      return;
    }
    if (!data.success) {
      if (info) info.textContent = `Erro ao verificar: ${data.error || "desconhecido"}`;
      return;
    }
    if (info) info.textContent = `Versão instalada: ${data.current_version} · Versão remota: ${data.remote.version}`;
    if (data.update_available) {
      const dismissed = localStorage.getItem("umbrel_dismissed_version");
      remoteManifestCache = data.remote;
      if (dismissed !== data.remote.version) {
        showUpdateBanner(data.remote);
      }
    } else if (showResultToast) {
      showToast("Você já está na versão mais recente.", "success");
    }
  } catch (e) { /* silencioso - checagem em segundo plano */ }
}

function showUpdateBanner(remote) {
  document.getElementById("bannerVersion").textContent = remote.version;
  document.getElementById("bannerDescription").textContent = remote.description || "";
  document.getElementById("updateBanner").classList.remove("d-none");
}

document.getElementById("btnBannerLater").addEventListener("click", () => {
  if (remoteManifestCache) localStorage.setItem("umbrel_dismissed_version", remoteManifestCache.version);
  document.getElementById("updateBanner").classList.add("d-none");
});

document.getElementById("btnBannerUpdate").addEventListener("click", async () => {
  document.getElementById("updateBanner").classList.add("d-none");
  // Muda pra aba Updates e já dispara o download+preview da versão remota
  document.querySelector('.nav-btn[data-tab="updates"]').click();
  showToast("Baixando atualização...", "info");
  try {
    const res = await apiFetch("/api/update/remote-stage", { method: "POST" });
    const data = await res.json();
    if (!data.success) { showToast(data.error, "error"); return; }
    stagedUpdateId = data.staging_id;
    const preview = document.getElementById("updatePreview");
    preview.classList.remove("d-none");
    preview.innerHTML = `
      <div class="update-hist-item">
        <strong>v${data.manifest.version || "?"}</strong> — ${data.manifest.description || ""}
        <div class="muted small">${data.files.length} arquivo(s) serão substituídos${data.has_post_install ? " · inclui script pós-instalação" : ""}</div>
      </div>
      <button class="btn btn-primary btn-sm" id="btnConfirmApply"><i class="fa-solid fa-check"></i> Aplicar esta atualização</button>`;
    document.getElementById("btnConfirmApply").addEventListener("click", applyStagedUpdate);
  } catch (e) {
    showToast("Erro ao baixar atualização remota.", "error");
  }
});

document.getElementById("btnCheckNow").addEventListener("click", () => checkRemoteUpdate(true));

// ---- Inicialização ----
loadCatalog();
loadInstalledApps();
loadRemoteUrlSetting();
checkRemoteUpdate(false);
setInterval(() => {
  if (!document.getElementById("tab-minecraft").classList.contains("d-none")) { refreshMcStatus(); refreshPlayitStatus(); }
  if (!document.getElementById("tab-monitor").classList.contains("d-none")) refreshSystemStats();
}, 8000);
setInterval(() => checkRemoteUpdate(false), 60000);